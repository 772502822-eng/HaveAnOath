from pathlib import Path
import json,hashlib
base=Path(__file__).resolve().parent
master=json.loads((base/'字幕母版-v13.json').read_text(encoding='utf-8'))
def stamp(seconds):
 n=round(seconds*1000)
 return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02}.{n%1000:03}'
rows=[]
for c in master:
 times=[c['filmStart']] if c.get('instant') else c['revealFilm']
 for j,a in enumerate(times):
  b=times[j+1] if j+1<len(times) else c['filmEnd']
  text=c['text'] if c.get('instant') else c['text'][:j+1]+''.join('ㅤ' if ord(ch)>255 else 'ﾠ' for ch in c['text'][j+1:])
  rows.append(f'{stamp(a*1.15625)} --> {stamp(b*1.15625)}\n{text}')
text='WEBVTT\n\nNOTE Each cue is one subtitle, as cut by hand in OpenFilm Studio.\nNOTE v13 first two opening lines are kinetic scene text, not subtitles.\n\n'+'\n\n'.join(rows)+'\n'
target=base/'原生字幕备份-v13/captions.vtt'
same=target.exists() and target.read_text()==text
target.write_text(text,encoding='utf-8')
print(f'v13: {len(master)}句 / {len(rows)}条片段；与现有VTT一致={same}；SHA256={hashlib.sha256(text.encode()).hexdigest()}')
