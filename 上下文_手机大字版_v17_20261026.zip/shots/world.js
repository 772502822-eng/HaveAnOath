'use strict';
const root=document.getElementById('stage');
// v16: move the picture toward the phone's central viewing area. Notes stay
// in their original reading band; one shared projection keeps every seam aligned.
const mobileLayout={scale:.9,x:54,y:260};
root.style.setProperty('--scene-scale',String(mobileLayout.scale));root.style.setProperty('--scene-x',mobileLayout.x+'px');root.style.setProperty('--scene-y',mobileLayout.y+'px');
function picturePoint(el){const r=el.getBoundingClientRect();return {x:(r.x-mobileLayout.x)/mobileLayout.scale,y:(r.y-mobileLayout.y)/mobileLayout.scale};}

const starts=[0,4.5,8.7,12,15.308,26.551,34.162,42.811,50.822],ends=[...starts.slice(1),58.9];
const div=(c,s,style='')=>`<div class="${c}" style="${style}">${s}</div>`;
const title=(a,b)=>`<h1><span class="title-line"><span class="title-ink">${a}</span></span><span class="title-line"><span class="title-ink">${b}</span></span></h1>`;
const names=['一次读入','长文本','容量 ≠ 记忆','材料位置','历史随行','历史输入量','三种价格','窗口容量','重新认识'];
// v14: narrative is kinetic scene typography, with scene-specific beats.
const kword=(text,mode='slide',key=false)=>({text,mode,key});
const kineticSpecs={
 1:[{a:0,b:1.86,lines:[['一段很长的'],[kword('上下文','spread',true)]]},{a:1.95,b:4.05,lines:[['甚至是一整本'],[kword('小说','book',true)]]}],
 3:[{a:0,b:3.308,lines:[['它只认真看了'],[kword('开头','left',true),'和',kword('结尾','right',true)]]}],
 4:[{a:.303,b:3.07,lines:[['第一轮，'],['带上',kword('一句','stamp',true)]]},{a:5.449,b:7.611,lines:[['第十轮，'],['带上',kword('十句','stamp',true)]]},{a:7.957,b:10.3,lines:[[kword('新问题，','right',true)],['连同',kword('旧对话','left',true)]]}],
 5:[{a:.13,b:3.07,lines:[['输入按 ',kword('token','slide',true)],[kword('计费','stamp',true)]]},{a:3.33,b:7.16,lines:[[kword('历史','lift',true),'也在'],['输入里']]}],
 6:[{a:.20,b:3.42,lines:[['相同的历史，'],['可以',kword('复用','reuse',true)]]},{a:3.72,b:8.20,lines:[[kword('命中缓存，','left',true)],[kword('单价更低','drop',true)]]}],
 7:[{a:.216,b:2.595,lines:[['从 ',kword('128K','number',true),'，'],['到 ',kword('1M','number',true)]]},{a:2.847,b:5.262,lines:[['变大的是'],[kword('上下文窗口','spread',true)]]},{a:5.515,b:7.95,lines:[['不等于有了'],[kword('长期记忆','deny',true)]]}],
 8:[{a:.345,b:3.027,lines:[['你聊得越久，'],[kword('历史越长','spread',true)]]},{a:3.286,b:5.189,lines:[['看起来，'],[kword('它记得你','gather',true)]]},{a:5.448,b:8.078,lines:[['它依靠的是'],[kword('当前上下文','context',true)]]}]
};
function kineticHeading(specs){return specs.map((beat,j)=>`<h1 class="kinetic-title" data-beat="${j}">${beat.lines.map((line,k)=>`<span class="k-line" data-line="${k}">${line.map(raw=>{const o=typeof raw==='string'?kword(raw):raw;return `<span class="k-word${o.key?' k-key':''}" data-motion="${o.mode}">${[...o.text].map(c=>`<span class="k-char">${c===' '?'&nbsp;':c}</span>`).join('')}</span>`}).join('')}</span>`).join('')}</h1>`).join('');}
function buildScene(scene){
let html="";
if(scene===0){
 html+=div('opening-premise','<b class="opening-million-key">100万</b> token，')+div('opening-read','<span>装得下</span><strong>一整本小说</strong>')+div('opening-forget','<span>却<em class="opening-not">未必</em>记得住</span>')
  +'<div id="million" class="number red">0</div><div id="unit">TOKENS / 上下文窗口</div><div id="small-rule"></div>'
  +div('opening-passages','<i class="opening-first-rule"></i>'+Array.from({length:6},(_,j)=>`<div class="opening-row" style="top:${90+j*48}px;width:${[756,680,728,610,756,540][j]}px"><i></i></div>`).join('')+'<i class="opening-scan"></i>')
  +div('opening-sentence','<span>第</span><span>一</span><span>句</span>')
  +div('ring','<strong class="mono red">1M</strong><span>一次读入</span>');
}
if(scene===1){html+=title('一整本小说，','也能装下。');for(let i=0;i<6;i++)html+=div('book',div('label mono',`CHAPTER ${String(i+1).padStart(2,'0')}`)+Array.from({length:7},(_,j)=>`<i style="width:${j===6?110:185}px"></i>`).join(''),`left:${120+i%3*294}px;top:${540+Math.floor(i/3)*345}px`);html+=div('footnote','长文本 · 当前这一轮的上下文');}
if(scene===2)html+=title('容量和记忆，','是两件事。')+div('compare',div('label','上下文容量')+'<strong>装得下</strong>','top:545px')+div('neq','<span class="neq-symbol">≠</span><span class="neq-words">不等于</span>')+div('compare',div('label','长期记忆')+'<strong>记得住</strong>','top:1050px')+div('source','这里讨论未接入外部记忆的模型调用');
if(scene===3)html+=`<svg viewBox="0 0 1080 1920"><path id="u-y-axis" class="axis" d="M180 510V1240"/><path id="u-x-axis" class="axis" d="M180 1240H950"/><path class="grid" d="M180 730H950 M180 970H950"/><text x="180" y="495">被用上的概率</text><text x="180" y="1305" text-anchor="middle">开头</text><text x="565" y="1305" text-anchor="middle">中间</text><text x="900" y="1305" text-anchor="middle">结尾</text><text x="900" y="1340" text-anchor="end">材料位置</text><path id="u-curve" class="curve" d="M190 595 C310 595 320 1140 565 1140 S830 595 940 595"/><circle id="pit" cx="565" cy="1140" r="12" fill="#B5342A"/><circle class="edge-focus" cx="190" cy="595" r="25" fill="none" stroke="#B5342A" stroke-width="2"/><circle class="edge-focus" cx="940" cy="595" r="25" fill="none" stroke="#B5342A" stroke-width="2"/></svg>`+title('装下了，','也可能漏掉中间。')+div('source','位置效应示意 · 非实测概率');
const messages=['你是旅行助手','我想去贵州','预算 2000 元','我有 3 天时间','从贵阳出发','不想太赶','喜欢山水','想吃当地小吃','给一份路线','再改得轻松些'];
if(scene===4){html+=title('每次提问，','都带上旧对话。');messages.forEach((s,i)=>html+=div('message',`<span class="seq mono">${String(i+1).padStart(2,'0')}</span>${s}`,`top:${510+i*64}px`));html+=div('scan','')+div('input-summary','<span>本轮输入</span><strong id="count" class="mono red">1</strong><span>条消息</span>')+div('formula','历史 + 新问题');}
if(scene===5)html+=title('旧对话，','也会进入账单。')+`<svg viewBox="0 0 1080 1920"><path id="input-y-axis" class="axis" d="M255 1310V490"/><path class="grid" d="M255 560H930 M255 790H930 M255 1020H930 M255 1250H930"/>${[[560,'第1轮'],[790,'第10轮'],[1020,'第50轮'],[1250,'第100轮']].map(([y,s])=>`<text x="225" y="${y+10}" text-anchor="end">${s}</text>`).join('')}<text x="900" y="1345" text-anchor="end">历史输入量 / 示意</text><path id="input-path" class="curve" d="M290 560 C330 710 335 800 440 925 S710 1170 900 1250"/><circle id="input-dot" r="8" fill="#1C1A17"/><circle class="history-dot" r="7" fill="#B5342A"/><circle class="history-dot" r="7" fill="#B5342A"/></svg>`;
if(scene===6){html+=title('输入、输出、缓存','三种价格。');[['输入','$0.30'],['输出','$1.20'],['命中缓存','$0.006']].forEach(([s,v],i)=>html+=div('price',div('label',s)+div('value number'+(i===2?' red':''),v)+div('unit','美元 / 百万 token'),`top:${540+i*245}px`));html+=`<svg class="reuse-loop" viewBox="0 0 1080 1920"><path id="reuse-loop" d="M760 280 C850 280 860 410 770 410 C680 410 680 280 760 280 M742 263 L760 280 L742 297" fill="none" stroke="#B5342A" stroke-width="3"/></svg>`+div('cache','命中部分 = 原价 <span class="mono red">1/50</span>')+div('source','DeepSeek V4.1-Flash / 高峰时段<br>2026.10.25 核实');}
if(scene===7)html+=`<svg class="window-bracket" viewBox="0 0 1080 1920"><path id="window-bracket" d="M182 900 H154 V1310 H182 M898 900 H926 V1310 H898" fill="none" stroke="#8A8578" stroke-width="2"/></svg>`+title('窗口变大，','不等于长期记忆。')+div('capacity',div('label','较小的窗口')+'<strong class="number">128K</strong>'+div('label','TOKENS'),'top:500px')+div('arrow','')+div('capacity',div('label','更大的窗口')+'<strong class="number red" style="font-size:184px">1M</strong>'+div('label','TOKENS'),'top:935px');
if(scene===8){html+=title('每一轮，','都带着历史相遇。')+div('person','你','top:475px')+div('person','AI','top:1030px')+div('history-label','当前上下文');for(let i=0;i<6;i++)html+=div('history-line','',`top:${780+i*36}px`);html+=div('closing','每一次，<span class="red">重新认识</span>')+div('source end-info','信息栏<br>Liu et al. · Lost in the Middle · TACL 2024<br>位置效应为论文结果示意，非所有模型的固定规律。<br>价格沿用原片口径：DeepSeek · 2026.10.25');}

const oldHeading=html.match(/<h1>[\s\S]*?<\/h1>/)?.[0]||'';
const heading=kineticSpecs[scene]?kineticHeading(kineticSpecs[scene]):oldHeading;
const source=html.match(/<div class="source(?: end-info)?"[^>]*>[\s\S]*?<\/div>/)?.[0]||'';
return `<article class="scene-panel scene-${scene}" data-scene="${scene}"><div class="scene-art">${heading}<div class="scene-content">${html.replace(oldHeading,'').replace(source,'')}</div></div>${source}</article>`;
}
root.innerHTML='<header id="page-header"></header>'+starts.map((_,i)=>buildScene(i)).join('')+'<div class="scene-bridges"><div id="carry-one" class="number">1</div><svg id="bridge-svg" viewBox="0 0 1080 1920"><path id="bridge-path"/></svg><svg id="outline-svg" viewBox="0 0 1080 1920"><path id="outline-carrier"/><path id="outline-copy-1"/><path id="outline-copy-2"/><path id="outline-copy-3"/><path id="outline-copy-4"/><path id="outline-copy-5"/><path id="axis-carrier"/><path id="person-carrier"/></svg></div><canvas id="paper" width="270" height="480"></canvas>';
// The grain has a fixed seed and stays anchored to the paper across every cut.
const cv=document.getElementById('paper'),ctx=cv.getContext('2d'),im=ctx.createImageData(270,480);let seed=73129;
for(let i=0;i<im.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const v=seed>>>24;im.data[i]=im.data[i+1]=im.data[i+2]=v;im.data[i+3]=255;}ctx.putImageData(im,0,0);
const panels=[...root.querySelectorAll('.scene-panel')],contents=panels.map(p=>p.querySelector('.scene-content'));
const $=(i,s)=>panels[i].querySelector(s),all=(i,s)=>[...panels[i].querySelectorAll(s)];
const cl=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=cl(x);return x*x*x*(x*(x*6-15)+10)},q=(t,a,d)=>smooth((t-a)/d),mix=(a,b,v)=>a+(b-a)*v;
function show(el,v,dy=0,scale=1){el.style.opacity=String(cl(v));el.style.transform=`translateY(${dy*(1-cl(v))}px) scale(${mix(scale,1,cl(v))})`;}
function mask(el,v,dy=38){el.style.opacity=v<=0?'0':'1';el.style.clipPath=`inset(${(1-cl(v))*100}% 0 0 0)`;el.style.transform=`translateY(${dy*(1-cl(v))}px)`;}
function trace(el,v){const len=el.getTotalLength();el.style.strokeDasharray=`${len} ${len}`;el.style.strokeDashoffset=String((1-cl(v))*len);}
function glyphs(el){const text=el.textContent;el.innerHTML=[...text].map(c=>`<span class="number-glyph"><span>${c}</span></span>`).join('');return [...el.querySelectorAll('.number-glyph > span')];}
const priceGlyphs=all(6,'.value').map(glyphs),capacityGlyphs=all(7,'.capacity strong').map(glyphs);
const reel=$ (0,'#million');reel.innerHTML='';
const slots=Array.from({length:9},()=>{const el=document.createElement('span');el.className='roll-slot';el.innerHTML='<span class="roll-track"><span></span><span></span></span>';reel.appendChild(el);return el;});
function rollNumber(el,value,small){
 const str=Math.floor(value+1e-7).toLocaleString('en-US'),chars=[...str];
 slots.forEach((slot,i)=>{slot.style.display=i<chars.length?'block':'none';if(i>=chars.length)return;
 const ch=chars[i],track=slot.firstElementChild,rows=track.children;
 if(ch===','){rows[0].textContent=',';rows[1].textContent=',';track.style.transform='translateY(0)';return;}
 const digitsAfter=chars.slice(i+1).filter(c=>c!==',').length,position=value/(10**digitsAfter),digit=Math.floor(position+1e-7)%10;
 const fraction=small||value>=1000000||(i===0&&digit===9)?0:q(position-Math.floor(position),.86,.14);
 rows[0].textContent=String(digit);rows[1].textContent=String((digit+1)%10);track.style.transform=`translateY(${-50*fraction}%)`;
 });
 el.setAttribute('aria-label',str);
}
const header=document.getElementById('page-header'),bridge=document.getElementById('bridge-path');
// One continuous ink stroke carries structure across the cut. Each pair has the same two cubic segments.
const bridges=[
 [[540,875,220,875,220,1355,540,1355,860,1355,860,875,540,875],[120,540,400,540,680,540,960,540,960,640,960,740,960,840]],
 [[120,840,120,740,120,640,120,540,400,540,680,540,960,540],[260,960,420,960,540,960,640,960,720,960,780,960,820,960]],
 [[440,900,480,900,520,900,560,900,600,900,640,900,680,900],[190,595,310,595,320,1140,565,1140,810,1140,830,595,940,595]],
 [[190,595,310,595,320,1140,565,1140,810,1140,830,595,940,595],[140,529,340,529,540,529,740,529,800,529,880,529,940,529]],
 [[140,1165,340,1165,540,1165,740,1165,810,1165,880,1165,940,1165],[255,490,255,760,255,1030,255,1310,480,1310,705,1310,930,1310]],
 [[290,560,330,710,335,800,440,925,600,1100,760,1230,900,1250],[120,540,400,540,680,540,960,540,960,785,680,1030,120,1030]],
 [[120,1030,340,1030,560,1030,780,1030,840,1030,900,1030,960,1030],[540,735,540,770,540,805,540,840,540,875,540,910,540,945]],
 [[540,735,540,770,540,805,540,840,540,875,540,910,540,945],[540,615,540,715,540,815,540,915,540,950,540,990,540,1030]]
];
function pathOf(v){return `M${v[0]} ${v[1]} C${v.slice(2,8).join(' ')} C${v.slice(8).join(' ')}`;}
function titleAt(i,t,leave=0){
 all(i,'.title-ink').forEach((el,j)=>{const enter=i===0?1:q(t,.06+j*.14,.48);el.style.transform=`translateY(${(1-enter)*108-leave*116}%)`;});
 if(!kineticSpecs[i])return;
 all(i,'.kinetic-title').forEach((head,j)=>{
  const beat=kineticSpecs[i][j],age=t-beat.a,exit=q(t,beat.b-.18,.18),visible=age>=0&&t<beat.b;
  head.style.display=visible?'block':'none';if(!visible)return;
  head.style.opacity=String((1-exit)*(1-leave));head.style.transform=`translateY(${-18*(exit+leave)}px)`;
  [...head.querySelectorAll('.k-word')].forEach((word,k)=>{
   const mode=word.dataset.motion,key=word.classList.contains('k-key'),v=q(age,.025*k,key?.46:.32),e=1-v;
   word.style.transform='none';word.style.opacity='1';word.style.clipPath='none';
   word.style.transformOrigin='0 50%';word.style.letterSpacing='0';
   let transform=`translateY(${22*e}px)`;
   if(mode==='left'||mode==='right')transform=`translateX(${(mode==='left'?-Math.min(90,Math.max(0,picturePoint(word).x-60)):90)*e}px)`;
   if(mode==='spread')transform=`scaleX(${mix(.68,1,v)})`;
   if(mode==='stamp')transform=`translateY(${-42*e}px) scale(${mix(1.18,1,v)})`;
   if(mode==='book')transform=`translateX(${110*e}px) scaleX(${mix(.35,1,v)})`;
   if(mode==='number')transform=`translateY(${30*e}px) scale(${mix(.7,1,v)})`;
   if(mode==='drop')transform=`translateY(${-32*e}px)`;
   if(mode==='gather')transform=`translateX(${80*e}px) scale(${mix(1.12,1,v)})`;
   if(mode==='lift')transform=`translateY(${140*e}px) scale(${mix(.65,1,v)})`;
   if(mode==='reuse')transform=`translate(${45*e}px,${-25*Math.sin(v*Math.PI)}px)`;
   if(mode==='context'){
    const v=q(age,0,.62),back=1-v,r=picturePoint(word),x=back**3*466+3*back**2*v*800+3*back*v*v*850+v**3*r.x,y=back**3*697+3*back**2*v*697+3*back*v*v*260+v**3*r.y,scale=mix(.44,1,q(v,.5,.5));
    transform=`translate(${x-r.x}px,${y-r.y}px) scale(${scale})`;
   }
   word.style.transform=transform;
   [...word.children].forEach((char,n)=>{const p=mode==='context'?1:q(age,.022*n+.025*k,.26);char.style.opacity=p>0?'1':'0';char.style.clipPath=`inset(${(1-p)*100}% -.04em -.08em -.04em)`;char.style.transform=`translateY(${(1-p)*28}px)`;});
   if(mode==='deny')word.style.setProperty('--mark',String(q(age,.55,.38)));else word.style.setProperty('--mark','0');
  });
 });
}
function drawScene(i,t){
 if(i===0){
  const collapse=q(t,2.40,.24),value=1000000*q(t,0,1.80);rollNumber(reel,value,t>=1.8);
  reel.style.left=mix(162,86,collapse)+'px';reel.style.top=(mix(540,540,collapse)-22*Math.sin(collapse*Math.PI))+'px';reel.style.fontSize=mix(148.33,60,collapse)+'px';reel.style.width=mix(756,320,collapse)+'px';
  const unit=$(0,'#unit');unit.style.left=mix(166,86,collapse)+'px';unit.style.top=mix(745,620,collapse)+'px';unit.style.fontSize=mix(34,30,collapse)+'px';show(unit,t<3?1-collapse:q(t,3,.35),12);
  const ring=$(0,'.ring'),ringIn=q(t,3,.58);ring.style.opacity=ringIn>0?'1':'0';ring.style.clipPath=`inset(${50*(1-ringIn)}% ${50*(1-ringIn)}%)`;ring.style.transform=`translateY(${35*(1-ringIn)}px) scale(${mix(.68,1,ringIn)})`;
  mask(ring.querySelector('strong'),q(t,3.22,.40),24);show(ring.querySelector('span'),q(t,3.52,.30),12);
  const rule=$(0,'#small-rule');rule.style.top='675px';rule.style.transformOrigin='left';rule.style.transform=`scaleX(${collapse})`;rule.style.opacity=String(collapse);
  // The opening lines are scene objects: reading fills the page, then the
  // same first-line object leaves the page and loses its ink at one million.
  show($(0,'.opening-premise'),1-q(t,2.38,.23));
  const read=$(0,'.opening-read'),forget=$(0,'.opening-forget'),sentence=$(0,'.opening-sentence');
  show(read,1-q(t,2.38,.23));read.style.transform=`translateY(${-24*q(t,2.38,.23)}px)`;
  read.style.setProperty('--emphasis',String(q(t,.55,.4)));
  read.querySelector('strong').style.clipPath=`inset(0 ${(1-q(t,0,.50))*100}% 0 0)`;
  forget.style.setProperty('--emphasis',String(q(t,2.55,.35)));
  mask(forget,q(t,2.45,.24),20);forget.style.opacity=String(q(t,2.45,.24)*(1-q(t,4.08,.28)));
  const lift=q(t,2.40,.55),back=1-lift;
  // Arc around the counter's right side; a straight lift crosses its glyphs.
  sentence.style.left=(back**3*162+3*back**2*lift*810+3*back*lift**2*730+lift**3*86)+'px';sentence.style.top=mix(825,390,lift*lift*(3-2*lift))+'px';sentence.style.fontSize=mix(44,94,lift)+'px';sentence.style.color=lift>.5?'#B5342A':'#686358';
  [...sentence.children].forEach((el,j)=>{const e=q(t,3.70+j*.055,.24);el.style.clipPath=`inset(0 0 0 ${e*100}%)`;el.style.opacity=e>=1?'0':'1';el.style.transform=`translateY(${-8*e}px)`;});
  const passages=$(0,'.opening-passages');passages.style.opacity=String(1-q(t,2.4,.28));
  all(0,'.opening-row').forEach((row,j)=>{const progress=cl((value/1000000)*7-(j+1));row.firstElementChild.style.transform=`scaleX(${progress})`;});
  $(0,'.opening-first-rule').style.transform=`scaleX(${cl(value/1000000*7)})`;
  // Finish on the last text row, pause, then let the stroke gather at its
  // right edge and lose its ink. Every state is derived from t for scrubbing.
  const scan=$(0,'.opening-scan'),scanOut=q(t,1.92,.42);
  scan.style.top=(40+cl(value/1000000)*290)+'px';
  scan.style.transformOrigin='right center';
  scan.style.transform=`scaleX(${1-scanOut})`;
  scan.style.opacity=String(1-scanOut);

 }
 if(i===1){all(1,'.book').forEach((el,j)=>{el.style.opacity='1';el.style.clipPath='none';el.style.transform='none';[...el.children].forEach((child,k)=>{const v=q(t,.76+j*.14+k*.025,.35);child.style.opacity=String(v);child.style.transformOrigin='0 50%';child.style.transform=k===0?`translateY(${10*(1-v)}px)`:`scaleX(${v})`;});});show($(1,'.footnote'),q(t,1.28,.40),14);}
 if(i===2){const boxes=all(2,'.compare');boxes.forEach((el,j)=>{show(el.querySelector('.label'),q(t,.14+j*1.03,.28),16);mask(el.querySelector('strong'),q(t,.34+j*1.03,.46),40);});mask($(2,'.neq'),q(t,.87,.4),30);show($(2,'.neq-symbol'),1-q(t,1.55,.3));show($(2,'.neq-words'),q(t,1.55,.3));show($(2,'.source'),q(t,1.8,.4),10);}
 if(i===3){
  const y=$(3,'#u-y-axis');y.style.opacity=t>=.30?'1':'0';trace(y,1);trace($(3,'#u-x-axis'),q(t,.30,.45));
  all(3,'svg .grid').forEach(e=>show(e,q(t,.45,.35)));
  all(3,'svg text').forEach((e,j)=>show(e,q(t,.22+j*.06,.28),6));
  const v=q(t,.82,1.27),curve=$(3,'#u-curve');trace(curve,v);curve.style.opacity=v>0?'1':'0';
  show($(3,'#pit'),q(t,1.95,.22),0,.45);all(3,'.edge-focus').forEach((el,j)=>{const v=q(t,.72+j*.22,.38)*(1-q(t,2.65,.30));show(el,v,0,.65);});show($(3,'.source'),q(t,.9,.3),10);
 }
 if(i===4){
  const arrivals=[.18,...Array.from({length:9},(_,j)=>3.35+j*.22)];
  const n=arrivals.filter(a=>t>=a).length||1,focus=q(t,7.957,.45);
  all(4,'.message').forEach((e,j)=>{mask(e,q(t,arrivals[j],.28),22);e.style.color=j===9&&focus>0?'#B5342A':'#1C1A17';e.style.fontWeight=j===9&&focus>0?'700':'500';});
  const count=$(4,'#count');count.textContent=n;show(count,q(t,.32,.35),20);
  show($(4,'.input-summary'),q(t,.18,.38),24);show($(4,'.formula'),q(t,7.957,.42),12);
  const scan=$(4,'.scan');scan.style.top=(510+(n-1)*64+58)+'px';scan.style.opacity=t>.18&&t<5.6?'.5':'0';
 }

 if(i===5){const axis=$(5,'#input-y-axis'),a=q(t,.24,.48);axis.style.opacity=a>0?'1':'0';axis.style.stroke='#1C1A17';trace(axis,a);all(5,'.grid').forEach((e,j)=>show(e,q(t,.48+j*.07,.28)));all(5,'svg text').forEach((e,j)=>show(e,q(t,.5+j*.13,.28),8));const plot=$(5,'#input-path'),v=q(t,.82,2.45);trace(plot,v);plot.style.opacity=v>0?'1':'0';const pos=plot.getPointAtLength(plot.getTotalLength()*v),dot=$(5,'#input-dot');dot.setAttribute('cx',pos.x);dot.setAttribute('cy',pos.y);dot.style.opacity=v>0?'1':'0';all(5,'.history-dot').forEach((el,j)=>{const age=t-3.33-j*.55,v=q(age,0,2.25),pt=plot.getPointAtLength(plot.getTotalLength()*v);el.setAttribute('cx',pt.x);el.setAttribute('cy',pt.y);el.style.opacity=String(q(age,0,.18)*(1-q(age,2.30,.28)));});}
 if(i===6){
  const cues=[.35,1.80,3.40];all(6,'.price').forEach((row,j)=>{const a=cues[j];row.style.opacity='1';row.style.transform='none';row.style.borderTopColor=`rgba(138,133,120,${q(t,j===0?0:a,.30)})`;show(row.querySelector('.label'),q(t,a,.26),12);priceGlyphs[j].forEach((g,k)=>{const v=q(t,a+.27+k*.052,.38);g.style.transform=`translateY(${(1-v)*115}%)`;g.style.opacity=v>0?'1':'0';});show(row.querySelector('.unit'),q(t,a+.84,.30),10);});show($(6,'.cache'),q(t,4.5,.35),14);show($(6,'.source'),q(t,.9,.35),8);const reuse=$(6,'#reuse-loop');trace(reuse,q(t,.3,.9));reuse.style.opacity=String(q(t,.3,.2)*(1-q(t,3.05,.3)));$(6,'.cache').style.setProperty('--cachemark',String(q(t,4.75,.5)));
 }
 if(i===7){
  const bracket=$(7,'#window-bracket');trace(bracket,q(t,2.847,.65));bracket.style.opacity=String(q(t,2.847,.2)*(1-q(t,7.25,.3)));
  t=t<=.32?t:.32+(t-.32)*(9.611/8.011);
  const groups=all(7,'.capacity');show(groups[0].children[0],q(t,.12,.30),15);
  capacityGlyphs[0].forEach((el,k)=>{const v=k===0?(t>=.32?1:0):q(t,.42+(k-1)*.10,.42);el.style.transform=`translateY(${(1-v)*115}%)`;el.style.opacity=v>0?'1':'0';});
  show(groups[0].children[2],q(t,1.12,.30),12);
  const arrow=$(7,'.arrow'),v=q(t,1.50,.48);arrow.style.opacity=v>0?'1':'0';arrow.style.transformOrigin='50% 0';arrow.style.transform=`scaleY(${v})`;
  show(groups[1].children[0],q(t,2.05,.30),15);
  capacityGlyphs[1].forEach((el,k)=>{const v=q(t,2.30+k*.085,.45);el.style.transform=`translateY(${(1-v)*115}%)`;el.style.opacity=v>0?'1':'0';});show(groups[1].children[2],q(t,3.05,.30),12);
 }
 if(i===8){const people=all(8,'.person');show(people[0],q(t,.74,.28));people[0].style.transform='none';people[0].style.borderColor='transparent';show($(8,'.history-label'),q(t,1.08,.30)*(1-q(t,5.448,.15)),15);all(8,'.history-line').forEach((el,j)=>{const v=q(t,1.30+j*.17,.35);el.style.opacity=v>0?'1':'0';el.style.transformOrigin='50% 50%';el.style.transform=`scaleX(${v})`;});show(people[1],q(t,2.65,.40),20,.9);mask($(8,'.closing'),q(t,5.8,.60),28);show($(8,'.source'),q(t,2.8,.45),10);}
}
function renderWorld(T){
 T=Math.max(0,Math.min(58.9,T));let active=0;for(let i=1;i<starts.length;i++)if(T>=starts[i])active=i;
 let cut=-1,u=0;for(let i=1;i<starts.length;i++){
  const before=i===7?.70:i===6?.45:i===1?.38:i===2?.40:i===3?.30:i===5?.38:i===8?.40:.24,after=i===7?.55:i===1?.42:i===2?.40:i===5?.24:i===8?.70:.40;
  if(T>=starts[i]-before&&T<=starts[i]+after){cut=i;u=cl((T-starts[i]+before)/(before+after));break;}
 }
 panels.forEach((panel,i)=>{const visible=cut<0?i===active:i===cut-1||i===cut;panel.style.display=visible?'block':'none';if(!visible)return;
  const local=Math.max(0,T-starts[i]);drawScene(i,local);let open=1,leave=0,dy=0,opacity=1,transform='translateY(0px)',origin='50% 50%';
  let lineAlpha=cut<0?1:i===cut-1?1-q(u,.08,.14):q(u,.72,.24);
  if(cut===6)lineAlpha=i===5?1-q(u,.0,.16):q(u,.62,.28);
  if(cut===7||cut===5||cut===1||cut===2||cut===3)lineAlpha=1;
  all(i,'svg .axis,svg .curve').forEach(e=>e.style.strokeOpacity=String(lineAlpha));
  all(i,'.ring,.book').forEach(e=>e.style.borderColor='transparent');
  all(i,'.message').forEach(e=>e.style.borderBottomColor=`rgba(138,133,120,${lineAlpha})`);
  all(i,'.input-summary').forEach(e=>e.style.borderTopColor=`rgba(28,26,23,${T>=starts[5]-.38?0:lineAlpha})`);
  if(i===6)all(i,'.price').forEach((e,j)=>e.style.borderTopColor=`rgba(138,133,120,${lineAlpha*q(local,[0,1.80,3.40][j],.30)})`);
  all(i,'.arrow,#pit').forEach(e=>e.style.opacity=String(Number(e.style.opacity||1)*lineAlpha));if(cut===8&&i===7)$(7,'.arrow').style.opacity='0';
  if(cut===1||cut===2){if(i===cut-1){opacity=1-q(u,.05,.64);leave=q(u,0,.65);}}
  else if(cut===5){if(i===4){opacity=1-q(u,.05,.62);leave=q(u,0,.62);}}
  else if(cut===8){if(i===7){const e=q(u,0,.48);origin='540px 840px';transform=`scale(${mix(1,.012,e)},${mix(1,.38,e)})`;opacity=1-q(u,.12,.42);leave=q(u,0,.48);}}
  else if(cut===7){
   if(i===6){const e=q(u,0,.58);origin='540px 875px';transform=`translate(${(428.6953125-540)*e}px,${(632.8984375-875)*e}px) scale(${mix(1,.035,e)},${mix(1,.14,e)})`;opacity=1-q(u,.40,.22);leave=q(u,0,.55);}
  }else if(cut===6){if(i===5){opacity=1-q(u,.05,.55);leave=q(u,0,.55);} }
  else if(cut>=0){if(i===cut-1){leave=smooth(u/.48);open=1-leave;dy=-26*leave;}else{open=q(u,.42,.58);dy=30*(1-open);}transform=`translateY(${dy}px)`;}
  const c=contents[i];c.style.clipPath=`inset(${(1-open)*50}% 0 ${(1-open)*50}% 0)`;c.style.transformOrigin=origin;c.style.transform=transform;c.style.opacity=String(opacity);titleAt(i,T-starts[i],leave);const source=$(i,'.source');if(source)source.style.opacity=String(Number(source.style.opacity||1)*opacity);
 });
 header.textContent=`CONTEXT / 02 · ${names[active]}`;header.style.opacity=T<3?'0':'1';
 const one=document.getElementById('carry-one');
 if(cut===7&&T<starts[7]+.32){one.style.opacity=String(q(u,.44,.18));}else one.style.opacity='0';
 if(cut===6){
  const from=[290,560,330,710,335,800,440,925,545,1050,710,1170,900,1250],to=[120,540,320,540,520,540,700,540,790,540,875,540,960,540],v=q(u,0,.86);
  bridge.setAttribute('d',pathOf(from.map((x,j)=>mix(x,to[j],v))));bridge.style.opacity=String(q(u,0,.14)*(1-q(u,.70,.26)));
 }else if(cut>=0&&![1,2,3,5,7,8].includes(cut)){const v=smooth(u),[a,b]=bridges[cut-1];bridge.setAttribute('d',pathOf(a.map((x,j)=>mix(x,b[j],v))));bridge.style.opacity=String(q(u,.06,.16)*(1-q(u,.78,.22)));}else bridge.style.opacity='0';
 drawPersistentOutlines(T,cut,u);
 root.dataset.globalTime=String(T);
}
const outline=document.getElementById('outline-carrier'),copies=Array.from({length:5},(_,j)=>document.getElementById('outline-copy-'+(j+1))),axisCarrier=document.getElementById('axis-carrier'),personCarrier=document.getElementById('person-carrier');
const K=.5522847498307936;
function circleShape(cx,cy,r){return [cx,cy-r,cx+K*r,cy-r,cx+r,cy-K*r,cx+r,cy,cx+r,cy+K*r,cx+K*r,cy+r,cx,cy+r,cx-K*r,cy+r,cx-r,cy+K*r,cx-r,cy,cx-r,cy-K*r,cx-K*r,cy-r,cx,cy-r];}
function rectShape(x,y,w,h){return [x,y,x+w/3,y,x+2*w/3,y,x+w,y,x+w,y+h/3,x+w,y+2*h/3,x+w,y+h,x+2*w/3,y+h,x+w/3,y+h,x,y+h,x,y+2*h/3,x,y+h/3,x,y];}
function closedShape(v){return `M${v[0]} ${v[1]} C${v.slice(2,8).join(' ')} C${v.slice(8,14).join(' ')} C${v.slice(14,20).join(' ')} C${v.slice(20).join(' ')} Z`;}
function interpolate(a,b,v){return a.map((x,j)=>mix(x,b[j],v));}
function putShape(el,v,alpha=1,progress=1,width=2){el.setAttribute('d',closedShape(v));el.style.opacity=String(alpha);el.style.strokeWidth=String(width);el.style.strokeDasharray='none';el.style.strokeDashoffset='0';if(progress<1)trace(el,progress);}
function drawPersistentOutlines(T,cut,u){
 [outline,...copies,axisCarrier,personCarrier].forEach(e=>e.style.opacity='0');
 const pages=Array.from({length:6},(_,j)=>rectShape(120.5+j%3*294,540.5+Math.floor(j/3)*345,251,299));
 const upper=rectShape(170.5,520.5,739,279),lower=rectShape(170.5,1025.5,739,279);
 if(T>=3&&T<4.12){const v=q(T,3,.58),scale=mix(.68,1,v);putShape(outline,circleShape(540,1115+35*(1-v),239*scale),v>0?1:0,v,2*scale);}
 else if(T>=4.12&&T<8.30){const v=q(T,4.12,.80);putShape(outline,interpolate(circleShape(540,1115,239),pages[0],v),1,1,2);for(let j=1;j<6;j++){const f=q(T,4.5+.30+j*.14,.36);putShape(copies[j-1],pages[j],f>0?1:0,f,2);}}
 else if(T>=8.30&&T<11.70){const v=q(T,8.30,.80),main=interpolate(pages[0],upper,q(v,.12,.88));putShape(outline,main,1,1,2);if(T<9.10){for(let j=1;j<6;j++)putShape(copies[j-1],interpolate(pages[j],main,q(v,0,.70)),1-q(v,.36,.34),1,2);}
  const f=q(T,9.10,.50);if(f>0)putShape(copies[0],interpolate(upper,lower,f),1,f,2);
 }
 else if(T>=11.70&&T<12.30){const v=q(T,11.70,.60),line=rectShape(180,510,0,730);putShape(outline,interpolate(upper,line,v),1,1,2);putShape(copies[0],interpolate(lower,line,v),1-q(v,.55,.40),1,2);}
 // The request separator remains the x axis; only the y axis is newly drawn.
 const a=starts[5]-.38,b=starts[5]+.24;
 if(T>=a&&T<starts[6]+.40){const v=q(T,a,b-a),x0=mix(140,255,v),y=mix(1166,1310,v),x1=mix(940,930,v);axisCarrier.setAttribute('d',`M${x0} ${y}H${x1}`);axisCarrier.style.opacity=String(T<starts[6]-.45?1:1-q((T-(starts[6]-.45))/.85,.05,.55));axisCarrier.style.stroke='#1C1A17';axisCarrier.style.strokeWidth='2';}
 // A closed degenerate line unrolls into the permanent circle around “你”.
 const c=starts[8]-.40,d=starts[8]+.70;
 if(T>=c){const v=q(T,c,d-c);putShape(personCarrier,interpolate(rectShape(540,735,0,210),circleShape(540,545,69),v),q(T,c,.12),1,2);personCarrier.style.stroke='#1C1A17';}
}

const offset=+document.body.dataset.start||0;
// Synchronous layout reset drops cached fractional-stroke rasters while retaining editable DOM nodes.
function rasterAt(T){root.style.display='none';void root.offsetHeight;root.style.display='block';renderWorld(T);void root.offsetHeight;}
window.draw=function(t){rasterAt(t+offset);};window.drawWorld=rasterAt;
const ready=Promise.all([document.fonts.load('700 72px SourceHanSerif'),document.fonts.load('500 72px SourceHanSans'),document.fonts.load('500 148px JetBrains')]).then(()=>document.fonts.ready);
window.film={duration:+document.body.dataset.duration,width:1080,height:1920,ready,frame:window.draw};window.draw(0);
