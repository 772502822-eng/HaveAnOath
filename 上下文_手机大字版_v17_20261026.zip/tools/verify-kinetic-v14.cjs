const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {chromium}=require('/Users/Zhuanz/Documents/ChatGPT/账号运营/.agents/skills/adu-motion-video/node_modules/playwright-core');
(async()=>{
const root=process.cwd(),out=root+'/review/v14';fs.mkdirSync(out+'/stills',{recursive:true});
const browser=await chromium.launch({executablePath:'/Applications/OpenFilm.app/Contents/Resources/runtime/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-mac-arm64/chrome-headless-shell',headless:true,args:['--allow-file-access-from-files','--force-color-profile=srgb']});
const p=await browser.newPage({viewport:{width:1080,height:1920}}),errors=[];p.on('pageerror',e=>errors.push(String(e)));await p.goto('file://'+out+'/player.html');await p.evaluate(()=>READY);
const times=[0,.6,1.4,2.35,2.55,2.75,2.95,3.3,3.8,4.05,4.4,5.3,6.2,7.4,8.5,9.4,10.7,11.5,12.9,14,15.9,17.4,19.8,21.5,23.8,25.3,27.5,29,30.4,32.3,34.8,36.3,38.3,40.5,42.5,43.7,44.8,46.5,48.9,50.3,51.9,53,54.6,55.6,56.3,56.5,56.7,57.1,58.8],shots=[];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const t of times){await p.evaluate(t=>draw(t),t);const png=await p.screenshot();fs.writeFileSync(out+'/stills/'+t+'.png',png);shots.push({t,sha:sha(png)});}
for(const s of [...shots].reverse()){await p.evaluate(t=>draw(t),s.t);if(sha(await p.screenshot())!==s.sha)throw Error('nondeterminism '+s.t);}
const geometry=[];
for(let n=0;n<589;n++){
 const t=n/10;await p.evaluate(t=>draw(t),t);const state=await p.evaluate(()=>{
  const d=document.getElementById('shot').contentDocument;const visible=e=>{while(e){const s=getComputedStyle(e);if(s.display==='none'||s.visibility==='hidden'||+s.opacity<.25)return false;e=e.parentElement}return true};
  const unsafe=[];for(const e of d.querySelectorAll('.k-word,.opening-read,.opening-premise,.opening-forget,.opening-sentence')){if(!visible(e))continue;const r=e.getBoundingClientRect();if(r.x<54||r.right>936||r.y<150||r.bottom>1360)unsafe.push({text:e.textContent,x:r.x,y:r.y,right:r.right,bottom:r.bottom});}
  const headWords=[...d.querySelectorAll('.kinetic-title .k-word')].filter(visible),body=[...d.querySelectorAll('.scene-content .price .label,.scene-content .message,.scene-content .person')].filter(visible),overlaps=[];
  for(const e of headWords){const a=e.getBoundingClientRect();for(const b of body){const r=b.getBoundingClientRect();if(a.x<r.right&&a.right>r.x&&a.y<r.bottom&&a.bottom>r.y)overlaps.push({text:e.textContent,body:b.textContent});}}
  return {unsafe,overlaps};
 });if(state.unsafe.length||state.overlaps.length)geometry.push({t,...state});
}
const messages=[];for(const [t,n] of [[17.4,1],[21.5,10],[24,10]]){await p.evaluate(t=>draw(t),t);const actual=await p.evaluate(()=>document.getElementById('shot').contentDocument.getElementById('count').textContent);messages.push({t,expected:n,actual:+actual});if(+actual!==n)throw Error('message count '+t);}
const files=['01','02','03','middle','04','05','06','07','08'],starts=[0,4.5,8.7,12,15.308,26.551,34.162,42.811,50.822],seams=[];
for(let i=1;i<starts.length;i++){let expected;for(const j of [i-1,i]){await p.goto('file://'+root+'/shots/'+files[j]+'.html');await p.evaluate(()=>film.ready);await p.evaluate(t=>draw(t),starts[i]-starts[j]);const hash=sha(await p.screenshot());if(expected&&hash!==expected)throw Error('page seam '+starts[i]);expected=hash;}seams.push({t:starts[i],identical:true});}
await browser.close();const result={frames:shots.length,repeat:'identical',geometrySamples:589,geometry,messages,seams,errors,shots};fs.writeFileSync(out+'/文字动画核验.json',JSON.stringify(result,null,2));console.log(JSON.stringify({frames:shots.length,geometrySamples:589,issues:geometry.slice(0,15),issueCount:geometry.length,messages,seams,errors},null,2));if(geometry.length||errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
