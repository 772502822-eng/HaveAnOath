const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {chromium}=require('/Users/Zhuanz/Documents/ChatGPT/账号运营/.agents/skills/adu-motion-video/node_modules/playwright-core');
(async()=>{
const root=process.cwd(),out=root+'/review/v17';fs.mkdirSync(out+'/stills',{recursive:true});
const browser=await chromium.launch({executablePath:'/Applications/OpenFilm.app/Contents/Resources/runtime/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-mac-arm64/chrome-headless-shell',headless:true,args:['--allow-file-access-from-files','--force-color-profile=srgb']});
const p=await browser.newPage({viewport:{width:1080,height:1920}}),errors=[];p.on('pageerror',e=>errors.push(String(e)));await p.goto('file://'+out+'/player.html');await p.evaluate(()=>READY);
const times=[0,1.4,3.3,7.4,10.7,14,17.4,20.8,21.5,23.3,23.4,23.5,24,27.5,38.3,44.8,48.9,53,56.7,58.8],shots=[];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const t of times){await p.evaluate(t=>draw(t),t);const png=await p.screenshot();fs.writeFileSync(out+'/stills/'+t+'.png',png);shots.push({t,sha:sha(png)});}
for(const s of [...shots].reverse()){await p.evaluate(t=>draw(t),s.t);if(sha(await p.screenshot())!==s.sha)throw Error('nondeterminism '+s.t);}
const geometry=[];
for(let n=0;n<589;n++){
 const t=n/10;await p.evaluate(t=>draw(t),t);const state=await p.evaluate(()=>{
  const d=document.getElementById('shot').contentDocument;const visible=e=>{while(e){const s=getComputedStyle(e);if(s.display==='none'||s.visibility==='hidden'||+s.opacity<.25)return false;e=e.parentElement}return true};
  const unsafe=[];for(const e of d.querySelectorAll('.k-word,.opening-read,.opening-premise,.opening-forget,.opening-sentence')){if(!visible(e))continue;const r=e.getBoundingClientRect();if(r.x<54||r.right>936||r.y<350||r.bottom>1360)unsafe.push({text:e.textContent,x:r.x,y:r.y,right:r.right,bottom:r.bottom});}
  const headWords=[...d.querySelectorAll('.kinetic-title .k-word')].filter(visible),body=[...d.querySelectorAll('.scene-content .price .label,.scene-content .message,.scene-content .person')].filter(visible),overlaps=[];
  for(const e of headWords){const a=e.getBoundingClientRect();for(const b of body){const r=b.getBoundingClientRect();if(a.x<r.right&&a.right>r.x&&a.y<r.bottom&&a.bottom>r.y)overlaps.push({text:e.textContent,body:b.textContent});}}
  const notes=[...d.querySelectorAll('.source')].filter(visible),noteBounds=[];
  for(const note of notes){const r=note.getBoundingClientRect();if(r.x<60||r.right>936||r.bottom>1685)noteBounds.push({text:note.textContent,x:r.x,y:r.y,right:r.right,bottom:r.bottom});}
  const actualHead=[...d.querySelectorAll('.kinetic-title')].filter(visible).map(e=>({y:e.getBoundingClientRect().y,text:e.textContent}));
  return {unsafe,overlaps,noteBounds,actualHead};
 });if(state.unsafe.length||state.overlaps.length||state.noteBounds.length)geometry.push({t,...state});
}
const messages=[];for(const [t,n] of [[17.4,1],[21.5,10],[24,10]]){await p.evaluate(t=>draw(t),t);const actual=await p.evaluate(()=>document.getElementById('shot').contentDocument.getElementById('count').textContent);messages.push({t,expected:n,actual:+actual});if(+actual!==n)throw Error('message count '+t);}
const files=['01','02','03','middle','04','05','06','07','08'],starts=[0,4.5,8.7,12,15.308,26.551,34.162,42.811,50.822],seams=[];
for(let i=1;i<starts.length;i++){let expected;for(const j of [i-1,i]){await p.goto('file://'+root+'/shots/'+files[j]+'.html');await p.evaluate(()=>film.ready);await p.evaluate(t=>draw(t),starts[i]-starts[j]);const hash=sha(await p.screenshot());if(expected&&hash!==expected)throw Error('page seam '+starts[i]);expected=hash;}seams.push({t:starts[i],identical:true});}
const phoneHtml=`<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#f7f3e9;width:780px;font:16px sans-serif}section{display:flex}figure{margin:0;width:390px}figcaption{height:30px;line-height:30px;padding-left:12px}img{display:block;width:390px;height:auto}</style>${['3.3','21.5','38.3','56.7'].map(t=>`<section>${['v16','v17'].map(v=>`<figure><figcaption>${v} / ${t}s</figcaption><img src="../${v}/stills/${t}.png"></figure>`).join('')}</section>`).join('')}`;
fs.writeFileSync(out+'/字号手机对比.html',phoneHtml);await p.goto('file://'+out+'/字号手机对比.html');await p.setViewportSize({width:780,height:2894});await p.screenshot({path:out+'/手机宽度字号对比.png',fullPage:true});
await browser.close();const result={frames:shots.length,repeat:'identical',geometrySamples:589,geometry,messages,seams,errors,shots};fs.writeFileSync(out+'/文字动画核验.json',JSON.stringify(result,null,2));console.log(JSON.stringify({frames:shots.length,geometrySamples:589,issues:geometry.slice(0,15),issueCount:geometry.length,messages,seams,errors},null,2));if(geometry.length||errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
