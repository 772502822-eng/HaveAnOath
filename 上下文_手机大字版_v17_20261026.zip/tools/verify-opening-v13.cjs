const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {chromium}=require('/Users/Zhuanz/Documents/ChatGPT/账号运营/.agents/skills/adu-motion-video/node_modules/playwright-core');
(async()=>{
const root=process.cwd(),out=root+'/review/v13';fs.mkdirSync(out+'/stills',{recursive:true});
const browser=await chromium.launch({executablePath:'/Applications/OpenFilm.app/Contents/Resources/runtime/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-mac-arm64/chrome-headless-shell',headless:true,args:['--allow-file-access-from-files','--force-color-profile=srgb']});
const p=await browser.newPage({viewport:{width:1080,height:1920}}),errors=[];p.on('pageerror',e=>errors.push(String(e)));await p.goto('file://'+out+'/player.html');await p.evaluate(()=>READY);
const times=[0,.28,.56,.84,1.13,1.2,1.49,1.55,1.65,1.72,1.8,1.9,2.05,2.35,2.7,2.85,3,3.2,3.6,4,4.3,4.5,4.8,5.2],shots=[];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const t of times){await p.evaluate(t=>draw(t),t);const state=await p.evaluate(()=>{const d=document.getElementById('shot').contentDocument;return {caption:document.getElementById('caption').textContent,number:d.getElementById('million').getAttribute('aria-label'),sentence:d.querySelector('.opening-sentence').textContent}});if(t<3&&state.caption.trim())throw Error('opening subtitle remains');const png=await p.screenshot();fs.writeFileSync(out+'/stills/'+t+'.png',png);shots.push({t,sha:sha(png),...state});}
for(const s of [...shots].reverse()){await p.evaluate(t=>draw(t),s.t);if(sha(await p.screenshot())!==s.sha)throw Error('nondeterminism '+s.t);}
const overlaps=[];for(let i=0;i<=80;i++){const t=1.5+i*.01;await p.evaluate(t=>draw(t),t);const overlap=await p.evaluate(()=>{const d=document.getElementById('shot').contentDocument,a=d.querySelector('.opening-sentence').getBoundingClientRect(),b=d.getElementById('million').getBoundingClientRect();return a.x<b.right&&a.right>b.x&&a.y<b.bottom&&a.bottom>b.y});if(overlap)overlaps.push(t);}
const later=[];for(const t of [14,40.5,58.8]){await p.evaluate(t=>draw(t),t);later.push({t,identicalToV12:sha(await p.screenshot())===sha(fs.readFileSync(root+'/review/v12/stills/'+t+'.png'))});}
const result={errors,frames:shots.length,repeat:'identical',trajectorySamples:81,counterOverlaps:overlaps,later,shots};fs.writeFileSync(out+'/开场动画核验.json',JSON.stringify(result,null,2));console.log(JSON.stringify({errors,frames:shots.length,trajectorySamples:81,counterOverlaps:overlaps,later},null,2));await browser.close();if(errors.length||overlaps.length||later.some(s=>!s.identicalToV12))process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
