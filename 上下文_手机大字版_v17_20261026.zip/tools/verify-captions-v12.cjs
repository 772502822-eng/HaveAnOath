const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {chromium}=require('/Users/Zhuanz/Documents/ChatGPT/账号运营/.agents/skills/adu-motion-video/node_modules/playwright-core');
(async()=>{
 const root=process.cwd(),out=path.join(root,'review/v12');
 const browser=await chromium.launch({executablePath:'/Applications/OpenFilm.app/Contents/Resources/runtime/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-mac-arm64/chrome-headless-shell',headless:true,args:['--allow-file-access-from-files','--force-color-profile=srgb']});
 const p=await browser.newPage({viewport:{width:1080,height:1920}}),errors=[];p.on('pageerror',e=>errors.push(String(e)));await p.goto('file://'+out+'/player.html');await p.evaluate(()=>READY);
 const times=await p.evaluate(()=>nativeCues.map(c=>(c.startMs+Math.min(c.durMs*.5,50))/1000));
 for(let t=0;t<58.9;t+=.2)times.push(+t.toFixed(3));
 const results=[],stills=[1,3.9,7.5,10.7,14,20.8,24,30.8,36.8,40.5,44.8,45,47,55.25,56.367,58.8];
 fs.mkdirSync(out+'/stills',{recursive:true});
 for(const t of [...new Set(times.concat(stills))].sort((a,b)=>a-b)){
  await p.evaluate(t=>draw(t),t);
  const r=await p.evaluate(()=>{
   const caption=document.querySelector('#caption>div>div');
   function textRects(doc,root){const walk=doc.createTreeWalker(root,NodeFilter.SHOW_TEXT),out=[];let n;while(n=walk.nextNode()){
    if(!n.textContent.trim()||n.parentElement.closest('script,style'))continue;
    let e=n.parentElement,visible=true;while(e){const s=getComputedStyle(e);if(+s.opacity<.15||s.display==='none'||s.visibility==='hidden')visible=false;e=e.parentElement;}if(!visible)continue;
    const range=doc.createRange();range.selectNodeContents(n);for(const r of range.getClientRects())if(r.width&&r.height){
     let x=r.x,y=r.y,right=r.right,bottom=r.bottom;
     // Rising number glyphs are cut by the existing inset mask. DOM Range
     // includes the hidden part; intersect with that mask before comparing.
     const mask=n.parentElement.closest('.number-glyph');
     if(mask){const b=mask.getBoundingClientRect(),f=parseFloat(getComputedStyle(mask).fontSize);x=Math.max(x,b.x-.10*f);right=Math.min(right,b.right+.10*f);y=Math.max(y,b.y-.12*f);bottom=Math.min(bottom,b.bottom+.08*f);}
     if(right>x&&bottom>y)out.push({text:n.textContent.replace(/[ㅤﾠ]/g,''),x,y,right,bottom});
    }
   }return out;}
   const c=textRects(document,document.getElementById('caption'));const d=document.getElementById('shot').contentDocument;const picture=textRects(d,d.getElementById('stage'));
   const overlap=[];for(const a of c)for(const b of picture)if(a.x<b.right&&a.right>b.x&&a.y<b.bottom&&a.bottom>b.y)overlap.push({caption:a,picture:b});
   const unsafe=c.filter(r=>r.x<54||r.right>935||r.bottom>1500||r.y<1360);
   const sources=picture.filter(r=>r.y>1490),sourceUnsafe=sources.filter(r=>r.right>925||r.bottom>1685);
   return {caption:c,overlap,unsafe,sourceUnsafe,sources};
  });
  results.push({t,...r});
  if(stills.includes(t)){await p.screenshot({path:out+'/stills/'+t+'.png'});}
 }
 const repeat=[];for(const t of [14,40.5,56.367,58.8]){await p.evaluate(t=>draw(t),t);const a=crypto.createHash('sha256').update(await p.screenshot()).digest('hex');await p.evaluate(()=>draw(1));await p.evaluate(t=>draw(t),t);repeat.push({t,identical:a===crypto.createHash('sha256').update(await p.screenshot()).digest('hex')});}
 await browser.close();const issues=results.filter(r=>r.overlap.length||r.unsafe.length||r.sourceUnsafe.length);
 fs.writeFileSync(out+'/字幕避让检查.json',JSON.stringify({samples:results.length,errors,repeat,issues,results},null,2));console.log(JSON.stringify({samples:results.length,errors,repeat,issues:issues.slice(0,8)},null,2));
 if(issues.length||errors.length||repeat.some(r=>!r.identical))process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
